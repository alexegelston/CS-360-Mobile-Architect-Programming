package com.example.alexegelston_module3;

import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Event> eventList;
    public interface ItemClickListener {
        void onItemClick(Event event);

        void onItemClick(View view, Event event);
    }
    private ItemClickListener itemClickListener;

    public EventAdapter(List<Event> eventList, ItemClickListener itemClickListener) {
        this.eventList = eventList;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public EventAdapter.EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        final Event event = eventList.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemClickListener.onItemClick(event);
            }
        });
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class EventViewHolder extends RecyclerView.ViewHolder {
        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
