package com.example.alexegelston_module3;

import androidx.recyclerview.widget.GridLayoutManager;

public class CustomRecyclerView {

    public void setLayoutManager(GridLayoutManager gridLayoutManager) {
    }
}
