package com.example.alexegelston_module3;
import java.io.Serializable;

public class Event implements Serializable{
    private String eventTitle;
    private String eventTime;
    private String eventDescription;

    public Event() {
    }


    public Event(String eventTitle, String eventTime, String eventDescription) {
        this.eventTitle = eventTitle;
        this.eventTime = eventTime;
        this.eventDescription = eventDescription;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public void setDescription(String description) {
    }

    public void setTitle(String title) {
    }
}
