package com.example.alexegelston_module3;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.example.alexegelston_module3.EventContract;
import com.example.alexegelston_module3.EventDbHelper;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {

    private EditText titleEditText;
    private EditText timeEditText;
    private EditText descriptionEditText;
    private Button saveButton;

    EventDbHelper dbHelper = new EventDbHelper(this);
    SQLiteDatabase db = dbHelper.getWritableDatabase();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        titleEditText = findViewById(R.id.titleEditText);
        timeEditText = findViewById(R.id.timeEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = titleEditText.getText().toString();
                String time = timeEditText.getText().toString();
                String description = descriptionEditText.getText().toString();

                // Create a new instance of the Event class and populate its properties
                Event newEvent = new Event();
                newEvent.setTitle(title);
                // Convert time to Date object using SimpleDateFormat or other methods
                // Set the converted Date object to the event
                newEvent.setDescription(description);

                // Save the new event to the data source (e.g., database or collection)
                // You'll need to implement the appropriate logic based on your chosen data storage mechanism

                // Show a success message or navigate back to the previous screen
                Toast.makeText(Activity3.this, "Event saved successfully", Toast.LENGTH_SHORT).show();
                finish(); // Finish the activity and return to the previous screen
            }
        });
    }
}