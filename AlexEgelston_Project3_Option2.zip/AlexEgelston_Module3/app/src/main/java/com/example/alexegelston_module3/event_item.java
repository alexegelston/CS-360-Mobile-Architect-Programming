package com.example.alexegelston_module3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.List;

public class event_item extends AppCompatActivity implements EventAdapter.ItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_item);

        recyclerView = findViewById(R.id.eventsRecyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        eventAdapter = new EventAdapter(eventList, (EventAdapter.ItemClickListener) this);
        recyclerView.setAdapter(eventAdapter);

        Event event = getIntent().getParcelableExtra("event");
    }

    @Override
    public void onItemClick(Event event) {

    }


    public interface ItemClickListener {
        void onItemClick(View view, Event event);
    }

    @Override
    public void onItemClick(View view, Event event) {
        Intent intent = new Intent(this, CustomRecyclerView.class);
        intent.putExtra("event", event);
        startActivity(intent);
    }


    private EventAdapter eventAdapter;
    private RecyclerView recyclerView;
    private List<Event> eventList;
}